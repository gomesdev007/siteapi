# Supabase

O projeto já possui as tabelas `gomes_licenses` e `gomes_license_logs` e a Edge Function `gomes-validate`.

Não coloque a service role key no Lua ou no frontend. Ela deve ficar apenas como variável de ambiente na Vercel.
