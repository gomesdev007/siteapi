const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

function auth(req) {
  const token = req.headers.authorization || "";
  return ADMIN_TOKEN && token === `Bearer ${ADMIN_TOKEN}`;
}

async function sb(path, options = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });
  const text = await r.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  return data;
}

export default async function handler(req, res) {
  if (!auth(req)) return res.status(401).json({error:"unauthorized"});
  try {
    if (req.method === "GET") {
      const rows = await sb("gomes_licenses?select=*&order=created_at.desc");
      return res.json(rows);
    }
    if (req.method === "POST") {
      const {action, license_key, days} = req.body || {};
      if (action === "create") {
        const key = license_key || `GOMES-${crypto.randomUUID().replaceAll("-","").slice(0,12).toUpperCase()}`;
        const d = Math.max(1, Math.min(3650, Number(days) || 30));
        const expires = new Date(Date.now() + d*86400000).toISOString();
        const rows = await sb("gomes_licenses", {method:"POST", headers:{Prefer:"return=representation"}, body:JSON.stringify({license_key:key,status:"active",expires_at:expires})});
        return res.status(201).json(rows[0]);
      }
      if (!license_key) return res.status(400).json({error:"license_key required"});
      if (action === "block" || action === "activate") {
        const status = action === "block" ? "blocked" : "active";
        const rows = await sb(`gomes_licenses?license_key=eq.${encodeURIComponent(license_key)}`, {method:"PATCH", headers:{Prefer:"return=representation"}, body:JSON.stringify({status})});
        return res.json(rows[0] || null);
      }
      if (action === "renew") {
        const d = Math.max(1, Math.min(3650, Number(days) || 30));
        const current = (await sb(`gomes_licenses?license_key=eq.${encodeURIComponent(license_key)}&select=expires_at`))[0];
        const start = current && new Date(current.expires_at) > new Date() ? new Date(current.expires_at) : new Date();
        start.setTime(start.getTime()+d*86400000);
        const rows = await sb(`gomes_licenses?license_key=eq.${encodeURIComponent(license_key)}`, {method:"PATCH", headers:{Prefer:"return=representation"}, body:JSON.stringify({status:"active",expires_at:start.toISOString()})});
        return res.json(rows[0] || null);
      }
      if (action === "reset") {
        const rows = await sb(`gomes_licenses?license_key=eq.${encodeURIComponent(license_key)}`, {method:"PATCH", headers:{Prefer:"return=representation"}, body:JSON.stringify({bound_user_id:null,bound_username:null})});
        return res.json(rows[0] || null);
      }
      if (action === "delete") {
        await sb(`gomes_licenses?license_key=eq.${encodeURIComponent(license_key)}`, {method:"DELETE"});
        return res.json({ok:true});
      }
    }
    return res.status(405).json({error:"method not allowed"});
  } catch(e) { return res.status(500).json({error:e.message}); }
}
