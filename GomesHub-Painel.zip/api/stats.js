const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

function auth(req) {
  const token = req.headers.authorization || "";
  return ADMIN_TOKEN && token === `Bearer ${ADMIN_TOKEN}`;
}

async function sb(path, options = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: SERVICE_KEY,
      Authorization: `Bearer ${SERVICE_KEY}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });
  const text = await r.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!r.ok) throw new Error(typeof data === "string" ? data : JSON.stringify(data));
  return data;
}

export default async function handler(req,res){
  if(!auth(req)) return res.status(401).json({error:"unauthorized"});
  try{
    const [licenses, logs] = await Promise.all([
      sb("gomes_licenses?select=status,uses_count,expires_at"),
      sb("gomes_license_logs?select=event,success,created_at&order=created_at.desc&limit=200")
    ]);
    const now=Date.now();
    const active=licenses.filter(x=>x.status==="active" && new Date(x.expires_at).getTime()>now).length;
    const expired=licenses.filter(x=>x.status==="expired" || new Date(x.expires_at).getTime()<=now).length;
    const blocked=licenses.filter(x=>x.status==="blocked").length;
    const uses=licenses.reduce((a,x)=>a+(Number(x.uses_count)||0),0);
    return res.json({total:licenses.length,active,expired,blocked,uses,logs:logs.length});
  }catch(e){return res.status(500).json({error:e.message});}
}
